package com.ram.samstrack.model;


@SuppressWarnings("serial")
public class Batch extends Student {
	
	private int rollNo_From;
	private int rollNo_To;
	
	public int getRollNo_From() {
		return rollNo_From;
	}
	public void setRollNo_From(int rollNo_From) {
		this.rollNo_From = rollNo_From;
	}
	public int getRollNo_To() {
		return rollNo_To;
	}
	public void setRollNo_To(int rollNo_To) {
		this.rollNo_To = rollNo_To;
	}
	
	
	
	

}
