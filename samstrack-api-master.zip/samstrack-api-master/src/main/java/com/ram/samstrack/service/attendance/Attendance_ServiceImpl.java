package com.ram.samstrack.service.attendance;

import java.io.Serializable;

import com.ram.samstrack.model.Practical_Attendance;
import com.ram.samstrack.model.Theory_Attendance;

public class Attendance_ServiceImpl implements Attendance_Service {

	@Override
	public Serializable save_Theory_Attendance(Theory_Attendance attendance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Serializable save_Practical_Attendance(Practical_Attendance attendance) {
		// TODO Auto-generated method stub
		return null;
	}

}
